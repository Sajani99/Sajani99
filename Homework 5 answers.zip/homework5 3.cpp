#include <iostream>
#include <math.h>
using namespace std;


double distancePoint(int x1, int y1, int x2, int y2);

int main(){
    int x1, y1, x2, y2;
    cout <<"=====First Point======" << endl;
    cout <<"Enter x1: ";
    cin>>x1;
    cout <<"Enter y1: ";
    cin>>y1;
    cout <<"=====Second point======" << endl;
    cout <<"Enter x2: ";
    cin>>x2;
    cout <<"Enter y2: ";
    cin>>y2;

   distancePoint(x1, y1, x2, y2);

}

double distancePoint(int x1, int y1, int x2, int y2){
    double distance = sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
    cout <<"distance of two points is " << distance << endl;
    return 0;
}

