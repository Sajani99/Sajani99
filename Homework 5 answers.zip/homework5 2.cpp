#include <iostream>
using namespace std;

int secCount(int h1, int m1, int s1, int h2, int m2, int s2){
    int second = 60 - s1;
    second =second + (60 - (m1 +1))*60;
    second = second + (h2 - (h1 +1))*3600;
    second = second + (m2 * 60) + s2;
    printf("Total Seconds between %d:%d:%d and %d:%d:%d is %d",h1,m1,s1,h2,m2,s2,second); 

    return 0;
}

int main(){

    int h1, m1, s1, h2, m2, s2;
    
    cout <<"=====Time 1======" << endl;
    cout <<"Input hours (Input between 0 - 12) : ";
    cin>>h1;
    cout <<"Input minutes (Input between 0 - 60) : ";
    cin>>m1;
    cout <<"Input seconds (Input between 0 - 60) : ";
    cin>>s1;
    cout <<"=====Time 2======" << endl;
    cout <<"Input hours (Input between 0 - 12): ";
    cin>>h2;
    cout <<"Input minutes (Input between 0 - 60): ";
    cin>>m2;
    cout <<"Input seconds (Input between 0 - 60): ";
    cin>>s2;
    
    secCount(h1, m1, s1, h2, m2, s2);
  
}
