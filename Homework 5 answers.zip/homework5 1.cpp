#include <iostream>
using namespace std;
int intPower(int Base, int exponent)
{
    
    int m = 1;
    while(true) {
    if(exponent <= 0){
        cout << "Invalid input for exponent,please try again........" << endl;
        cout << "Input exponent (Exponent must be a positive non-zero integer) : ";
        cin >> exponent ;
        continue;
        }
    else{
        for(int i = 0; i < exponent; i++){
            m = m * Base;
        }
        printf("%d ^ %d = %d", Base, exponent, m);
        break;
    }
    }
    return 0;
    
}
int main()
{
    int Base;
    int exponent;
    cout << "Input Base (Base must be an Integer) : ";
    cin >> Base ;
    cout << "Input exponent (Exponent must be a positive non-zero integer) : ";
    cin >> exponent ;
    intPower(Base, exponent);
}
   

    

