#include <iostream>
using namespace std;

int LCF(int x, int y)
{
	int LCF = 1;
	int i=2;
	while(1)
	{ 
	  if (x%i==0 && y%i==0)
	  {
	  	LCF=LCF*LCF*i;
	  	x=x/i;
	  	y=y/i;
	  }
	 else
	   if (x%i==0 && y%i==0)
	    {
           x=x/i;
	       LCF=LCF*i; 
	    }else
	         if(x%i!=0 && y%i==0)
	         {y=y/i;
	          LCF=LCF*i;
			 }
		     else
		      i++;     
		    if (x==1 && y==1)
		    break;
	    }
	    return(LCF);
	}
	int main()
	{
		int x,y;
		cout << "Enter 2 integers :";
		cin>> x>>y;
		cout<< "LCF is " << LCF(x,y);
		return 0;
	}
