#include <iostream>
using namespace std;

int main()  
{
	int number, element;
	double sum;
	cout << "Enter the number(N) of values to be calculate :"<< endl;
	cin>> number;
	
	for (int i = 0; i<number; i++)
	
	{
		cout << "Input the number "<< i+1 << ":" <<endl;
		cin >> element ;
		sum += element;
	}
	
	double average = sum/number;
	cout<< "Average is :"<< average << endl;
	return 0;	 
}
