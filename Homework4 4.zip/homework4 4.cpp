#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int size;
    int count = 0;
    int inputNumber;

    while (true)
    {
        cout << "Enter number of values want to enter(must be bigger than 3)" << endl;
        cin >> size;

        if (size > 3)
        {
            break;
        }
        else
        {
            cout << "Enter Number of values bigger than 3" << endl;
        }
    }

    int numberList[size];

    while (true)
    {
        if (count >= size)
            break;

        cout << "Enter Number " << count + 1 << endl;
        cin >> inputNumber;
        numberList[count] = inputNumber;
        count++;
    }
    sort(numberList, numberList + size);

    cout << "Third smallest number is : " << numberList[2] << endl;

    return 0;
}
