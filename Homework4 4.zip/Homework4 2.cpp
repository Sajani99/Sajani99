#include <iostream>
using namespace std;
int main()
{
    int count = 0;
    int total = 0;
    int size;
    int inputNumber;
    double average;

    cout << "Enter number of values want to enter : " << endl;
    cin >> size;

   for(int i=0;i<size;i++)
    {
        cout << "Enter Number " << i+1 <<" :"<< endl;
        cin >> inputNumber;
        if (inputNumber > 10)
        { 
            total += inputNumber;
			count++;
        }	 
    }
    average = total / count;
    cout << "average : " << average << endl;

    return 0;
}
