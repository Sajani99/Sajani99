#include <iostream>
using namespace std;

int great (int x, int y)
{
  int great=1;
  int i=2;
  while (x!=1 && y%i==0)
  {
  	if (x%i==0 && y%i==0)
  	{
  		great=great*i;
  		x=x/i;
  		y=y/i;
  	}
  	else
  	   if (x%i==0 && y%i!=0)
  	      x=x/i;
  	    else
		    if (x%i!=0 && y%i==0)  
		       y=y/i;
		       else i++;
	  }	
	  return (great);
}

int main ()
{
	int x,y;
	cout<< "Enter 2 integers : ";
	cin>>x>>y;
	cout<< "Great common divisor is " << great<< (x,y);
	return 0;
}
