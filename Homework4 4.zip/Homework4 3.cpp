#include <iostream>
using namespace std;

int main()
{
    int count = 0;
    int size;
    int inputNumber;
    int min;
    int max;

    cout << "Enter number of values want to enter : " << endl;
    cin >> size;

    while (true)
    {
        if (count >= size)
            break;

        cout << "Enter Number " << count + 1 << endl;
        cin >> inputNumber;

        if (count == 0)
        {
           min = inputNumber;
            max = inputNumber;
            count++;
            continue;
        }

        if (inputNumber < min)
           min = inputNumber;

        if (inputNumber > max)
            max = inputNumber;

        count++;
    }

    cout << "Smallest number : " << min << endl;
    cout << "Largest number : " <<max << endl;

    return 0;
}
